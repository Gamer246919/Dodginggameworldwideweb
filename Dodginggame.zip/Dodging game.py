import pygame
import random

# Initialize Pygame
pygame.init()

# Set up the game window
width, height = 600, 400
screen = pygame.display.set_mode((width, height))
pygame.display.set_caption("Dodging Game")

# Colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)

# Set up clock
clock = pygame.time.Clock()
player_width = 50
player_height = 50
player_speed = 5

# Game variables
player_x = width // 2
player_y = height - player_height - 10
player_velocity = 0

# Obstacle variables
obstacle_width = 50
obstacle_height = 50
obstacle_speed = 5
obstacles = []

# Font for score
font = pygame.font.SysFont("Arial", 30)

# Function to draw the player
def draw_player(x, y):
    pygame.draw.rect(screen, WHITE, (x, y, player_width, player_height))

# Function to draw obstacles
def draw_obstacles():
    for obstacle in obstacles:
        pygame.draw.rect(screen, RED, obstacle)

# Function to move obstacles
def move_obstacles():
    global obstacles
    for obstacle in obstacles:
        obstacle.y += obstacle_speed
    obstacles = [obstacle for obstacle in obstacles if obstacle.y < height]  # Remove off-screen obstacles

# Function to check collision
def check_collision():
    global player_x, player_y
    player_rect = pygame.Rect(player_x, player_y, player_width, player_height)
    for obstacle in obstacles:
        if player_rect.colliderect(obstacle):
            return True
    return False

# Main game loop
def game_loop():
    global player_x, player_velocity, obstacles
    score = 0
    running = True

    while running:
        screen.fill(BLACK)
        
        # Handle events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        # Move the player based on key presses
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] and player_x > 0:
            player_x -= player_speed
        if keys[pygame.K_RIGHT] and player_x < width - player_width:
            player_x += player_speed

        # Add new obstacles
        if random.randint(1, 100) <= 5:  # Adjust probability for more/less obstacles
            new_obstacle_x = random.randint(0, width - obstacle_width)
            obstacles.append(pygame.Rect(new_obstacle_x, -obstacle_height, obstacle_width, obstacle_height))

        # Move obstacles
        move_obstacles()

        # Check for collision
        if check_collision():
            running = False

        # Draw everything
        draw_player(player_x, player_y)
        draw_obstacles()

        # Update the score
        score += 1

        # Display score
        score_text = font.render(f"Score: {score}", True, WHITE)
        screen.blit(score_text, (10, 10))

        pygame.display.update()
        
        # Set frame rate
        clock.tick(60)  # 60 FPS

    # Game over
    game_over_text = font.render(f"Game Over! Final Score: {score}", True, WHITE)
    screen.blit(game_over_text, (width // 3, height // 3))
    pygame.display.update()
    pygame.time.wait(2000)  # Wait for 2 seconds before quitting

    pygame.quit()

# Start the game
game_loop()
